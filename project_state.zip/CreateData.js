// src/components/features/CreateData.js
import React from 'react';
import CreateDataContainer from './CreateDataContainer';

function CreateData() {
  return <CreateDataContainer />;
}

export default CreateData;
