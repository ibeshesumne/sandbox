// UpdateData.js
import React from "react";
import UpdateDataContainer from "./UpdateDataContainer";

function UpdateData() {
  return <UpdateDataContainer />;
}

export default UpdateData;