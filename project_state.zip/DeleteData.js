// DeleteData.js
import React from 'react';
import DeleteDataContainer from './DeleteDataContainer';

function DeleteData() {
  return <DeleteDataContainer />;
}

export default DeleteData;
